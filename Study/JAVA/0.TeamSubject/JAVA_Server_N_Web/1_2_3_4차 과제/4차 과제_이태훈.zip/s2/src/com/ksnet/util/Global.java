package com.ksnet.util;

public class Global {
	
	/*public static final String FC_RESET		= "\u001B[0m";	// Font Color (Console)
	public static final String FC_BLACK		= "\u001B[30m";
	public static final String FC_RED		= "\u001B[31m";
	public static final String FC_GREEN		= "\u001B[32m";
	public static final String FC_YELLOW	= "\u001B[33m";
	public static final String FC_BLUE		= "\u001B[34m";
	public static final String FC_PURPLE	= "\u001B[35m";
	public static final String FC_CYAN		= "\u001B[36m";
	public static final String FC_WHITE		= "\u001B[37m";
	
	public static final String BC_BLACK		= "\u001B[40m";		// Background Color (Console)
	public static final String BC_RED		= "\u001B[41m";
	public static final String BC_GREEN		= "\u001B[42m";
	public static final String BC_YELLOW	= "\u001B[43m";
	public static final String BC_BLUE		= "\u001B[44m";
	public static final String BC_PURPLE	= "\u001B[45m";
	public static final String BC_CYAN		= "\u001B[46m";
	public static final String BC_WHITE		= "\u001B[47m";*/
	
	public static final String FC_RESET		= "\u001B[0m";		// Font Color (Console)
	public static final String FC_BLACK		= "\u001B[0;90m";
	public static final String FC_RED		= "\u001B[0;91m";
	public static final String FC_GREEN		= "\u001B[0;92m";
	public static final String FC_YELLOW	= "\u001B[0;93m";
	public static final String FC_BLUE		= "\u001B[0;94m";
	public static final String FC_PURPLE	= "\u001B[0;95m";
	public static final String FC_CYAN		= "\u001B[0;96m";
	public static final String FC_WHITE		= "\u001B[0;97m";
	
	public static final String BC_BLACK		= "\u001B[1;90m";	// Background Color (Console)
	public static final String BC_RED		= "\u001B[1;91m";
	public static final String BC_GREEN		= "\u001B[1;92m";
	public static final String BC_YELLOW	= "\u001B[1;93m";
	public static final String BC_BLUE		= "\u001B[1;94m";
	public static final String BC_PURPLE	= "\u001B[1;95m";
	public static final String BC_CYAN		= "\u001B[1;96m";
	public static final String BC_WHITE		= "\u001B[1;97m";
}