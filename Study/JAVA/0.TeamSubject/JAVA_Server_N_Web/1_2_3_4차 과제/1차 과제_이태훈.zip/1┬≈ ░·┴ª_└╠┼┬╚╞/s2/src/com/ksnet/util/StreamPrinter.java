package com.ksnet.util;

import java.util.Arrays;

import com.ksnet.net.*;

/* [StreamPrinter]
 * ByteStream�� streamType�� ���� ������Ŀ� ���� ������ִ� Ŭ����.
 *
 * 1) void printStream() : ������ ���
 */

// �����
public class StreamPrinter {
	
	private ByteStream byteStream;
	
	// ������
	public StreamPrinter(ByteStream byteStream) {
		this.byteStream = byteStream;
	}
	
	// ��ĺ� ����Լ�
	// �ϳ�����_������ü_ǥ����
	private int print_hana_head(int beginIndex, byte[] byteAry) {
		System.out.println("=[ǥ����]=================================================================================");
		int index = beginIndex;
		String idCode			= new String(Arrays.copyOfRange(byteAry, index, index += 1));
		String taskComp			= new String(Arrays.copyOfRange(byteAry, index, index += 2));
		String bankCode			= new String(Arrays.copyOfRange(byteAry, index, index += 3));
		String companyCode		= new String(Arrays.copyOfRange(byteAry, index, index += 8));
		String comissioningDate	= new String(Arrays.copyOfRange(byteAry, index, index += 6));
		String processingDate	= new String(Arrays.copyOfRange(byteAry, index, index += 6));
		String motherAccountNum	= new String(Arrays.copyOfRange(byteAry, index, index += 14));
		String transferType		= new String(Arrays.copyOfRange(byteAry, index, index += 2));
		String companyNum		= new String(Arrays.copyOfRange(byteAry, index, index += 6));
		String resultNotifyType	= new String(Arrays.copyOfRange(byteAry, index, index += 1));
		String transferCnt		= new String(Arrays.copyOfRange(byteAry, index, index += 1));
		String password			= new String(Arrays.copyOfRange(byteAry, index, index += 8));
		String blank			= new String(Arrays.copyOfRange(byteAry, index, index += 19));
		String format			= new String(Arrays.copyOfRange(byteAry, index, index += 1));
		String VAN				= new String(Arrays.copyOfRange(byteAry, index, index += 2));
		index += 2; // ���� ����(CR+LF) ����
		
		int accumCnt = 0, strLength = 0;
		System.out.println("No\t�׸�\t\t\t\t����\t\t����\t\t������");
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 1, "�ĺ� �ڵ�", 		strLength = idCode.getBytes().length, 			accumCnt += strLength, idCode));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 2, "���� ����", 		strLength = taskComp.getBytes().length, 		accumCnt += strLength, taskComp));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 3, "���� �ڵ�",			strLength = bankCode.getBytes().length, 	 	accumCnt += strLength, bankCode));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 4, "��ü �ڵ�", 		strLength = companyCode.getBytes().length,	 	accumCnt += strLength, companyCode));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 5, "��ü �Ƿ� ����",	 	strLength = comissioningDate.getBytes().length,	accumCnt += strLength, comissioningDate));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 6, "��ü ó�� ����",		strLength = processingDate.getBytes().length,	accumCnt += strLength, processingDate));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 7, "����� ��ȣ",		strLength = motherAccountNum.getBytes().length,	accumCnt += strLength, motherAccountNum));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 8, "��ü ����", 		strLength = transferType.getBytes().length, 	accumCnt += strLength, transferType));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 9, "ȸ�� ��ȣ", 		strLength = companyNum.getBytes().length, 		accumCnt += strLength, companyNum));
		System.out.println(String.format("%d\t%s\t\t%d\t\t%d\t\t%s",   10, "ó����� �뺸 ����",	strLength = resultNotifyType.getBytes().length, accumCnt += strLength, resultNotifyType));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 11, "���� ����", 		strLength = transferCnt.getBytes().length, 		accumCnt += strLength, transferCnt));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 12, "��й�ȣ", 		strLength = password.getBytes().length, 		accumCnt += strLength, password));
		System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 13, "����", 			strLength = blank.getBytes().length, 			accumCnt += strLength, blank));
		System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 14, "����", 			strLength = format.getBytes().length, 			accumCnt += strLength, format));
		System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 15, "��", 			strLength = VAN.getBytes().length, 				accumCnt += strLength, VAN));
		
		return index;
	}
	
	// �ϳ�����_������ü_�����ͺ�
	private int print_hana_data(int beginIndex, byte[] byteAry) {
		System.out.println("=[�����ͺ�]================================================================================");
		int dataCnt = byteStream.getDataCnt();
		int index = beginIndex;
		
		for (int i = 0; i < dataCnt; ++i) {
			if (i > 0) System.out.println("---------------------------------------------------------------------------------------");
			String idCode				= new String(Arrays.copyOfRange(byteAry, index, index += 1));	// 1
			String dataSerialNum		= new String(Arrays.copyOfRange(byteAry, index, index += 6));	// 2
			String bankCode				= new String(Arrays.copyOfRange(byteAry, index, index += 3));	// 3
			String accountNum			= new String(Arrays.copyOfRange(byteAry, index, index += 14));	// 4
			String requestTransferPrice = new String(Arrays.copyOfRange(byteAry, index, index += 11));	// 5
			String realTransferPrice	= new String(Arrays.copyOfRange(byteAry, index, index += 11));	// 6
			String recieverIdNum		= new String(Arrays.copyOfRange(byteAry, index, index += 13));	// 7
			String processingResult	 	= new String(Arrays.copyOfRange(byteAry, index, index += 1));	// 8
			String disableCode			= new String(Arrays.copyOfRange(byteAry, index, index += 4));	// 9
			String briefs				= new String(Arrays.copyOfRange(byteAry, index, index += 12));	// 10
			String blank				= new String(Arrays.copyOfRange(byteAry, index, index += 4));	// 11
			index += 2; // ���� ����(CR+LF) ����
			
			int accumCnt = 0, strLength = 0;
			System.out.println("[������ #" + i +"]");
			System.out.println("No\t�׸�\t\t\t\t����\t\t����\t\t������");
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 1, "�ĺ� �ڵ�", 	strLength = idCode.getBytes().length, 				accumCnt += strLength, idCode));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 2, "������ �Ϸù�ȣ", 	strLength = dataSerialNum.getBytes().length, 		accumCnt += strLength, dataSerialNum));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 3, "���� �ڵ�",		strLength = bankCode.getBytes().length, 	 		accumCnt += strLength, bankCode));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 4, "���� ��ȣ", 	strLength = accountNum.getBytes().length,	 		accumCnt += strLength, accountNum));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 5, "��ü ��û �ݾ�",	strLength = requestTransferPrice.getBytes().length,	accumCnt += strLength, requestTransferPrice));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 6, "���� ��ü �ݾ�",	strLength = realTransferPrice.getBytes().length,	accumCnt += strLength, realTransferPrice));
			System.out.println(String.format("%d\t%s\t\t%d\t\t%d\t\t%s",   7, "�ֹ�/����� ��ȣ",	strLength = recieverIdNum.getBytes().length,		accumCnt += strLength, recieverIdNum));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 8, "ó�� ���", 	strLength = processingResult.getBytes().length, 	accumCnt += strLength, processingResult));
			System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 9, "�Ҵ� �ڵ�", 	strLength = disableCode.getBytes().length, 			accumCnt += strLength, disableCode));
			System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 10, "����",		strLength = briefs.getBytes().length, 				accumCnt += strLength, briefs));
			System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 11, "����", 		strLength = blank.getBytes().length, 				accumCnt += strLength, blank));
		}
		
		return index;
	}
	
	// �ϳ�����_������ü_�����
	private int print_hana_tail(int beginIndex, byte[] byteAry) {
		System.out.println("=[�����]=================================================================================");
		int index = beginIndex;
		
		String idCode					= new String(Arrays.copyOfRange(byteAry, index, index += 1));
		String totalRequestCnt			= new String(Arrays.copyOfRange(byteAry, index, index += 7));
		String totalRequestPrice		= new String(Arrays.copyOfRange(byteAry, index, index += 13));
		String normalProcessingCnt		= new String(Arrays.copyOfRange(byteAry, index, index += 7));
		String normalProcessingPrice	= new String(Arrays.copyOfRange(byteAry, index, index += 13));
		String disableProcessingCnt		= new String(Arrays.copyOfRange(byteAry, index, index += 7));
		String disableProcessingPrice	= new String(Arrays.copyOfRange(byteAry, index, index += 13));
		String recoveryCode				= new String(Arrays.copyOfRange(byteAry, index, index += 8));
		String blank					= new String(Arrays.copyOfRange(byteAry, index, index += 11));
		index += 2; // ���� ����(CR+LF) ����

		int accumCnt = 0, strLength = 0;
		System.out.println("No\t�׸�\t\t\t\t����\t\t����\t\t������");
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 1, "�ĺ� �ڵ�", 	strLength = idCode.getBytes().length, 					accumCnt += strLength, idCode));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 2, "�� �Ƿ� �Ǽ�", 	strLength = totalRequestCnt.getBytes().length, 			accumCnt += strLength, totalRequestCnt));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 3, "�� �Ƿ� �ݾ�",	strLength = totalRequestPrice.getBytes().length,		accumCnt += strLength, totalRequestPrice));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 4, "���� ó�� �Ǽ�", 	strLength = normalProcessingCnt.getBytes().length,		accumCnt += strLength, normalProcessingCnt));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 5, "���� ó�� �ݾ�", 	strLength = normalProcessingPrice.getBytes().length,	accumCnt += strLength, normalProcessingPrice));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 6, "�Ҵ� ó�� �Ǽ�",	strLength = disableProcessingCnt.getBytes().length,		accumCnt += strLength, disableProcessingCnt));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 7, "�Ҵ� ó�� �ݾ�",	strLength = disableProcessingPrice.getBytes().length,	accumCnt += strLength, disableProcessingPrice));
		System.out.println(String.format("%d\t%s\t\t\t%d\t\t%d\t\t%s", 8, "���� ��ȣ", 	strLength = recoveryCode.getBytes().length,				accumCnt += strLength, recoveryCode));
		System.out.println(String.format("%d\t%s\t\t\t\t%d\t\t%d\t\t%s", 9, "����", 		strLength = blank.getBytes().length,					accumCnt += strLength, blank));
		
		return index;
	}

	// ��Ʈ�� ���
	public void printStream() {
		byte[] byteAry = byteStream.getByteStream();
		
		// �ϳ�����_������ü_ǥ����_�����ͺ�_����� ��� ���
		if (byteStream.getStreamType().equals("HanaRecord")) {
			int nextIndex = print_hana_head(0, byteAry);
			nextIndex = print_hana_data(nextIndex, byteAry);
			print_hana_tail(nextIndex, byteAry);
		}
		// ��ȭ �߹�ŷ ��� ���
		else if (byteStream.getStreamType().equals("HanaRecordRecv")) {
			// ...
		}
		else if (false) {
			// ���⿡ ���ο� ���Ÿ�� �߰�...
		}
		else {
			System.out.println(this.getClass().getName());
			System.out.println("[����: �������� �ʴ� ���� ����.]");
			// ...
		}
	}
}