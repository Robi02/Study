package com.ksnet.net;

import java.io.FileOutputStream;
import java.io.IOException;

public class KsFileWriter {

	private String filePath;
	FileOutputStream fos = null;
	
	public KsFileWriter(String filePath) {
		this.filePath = filePath;
	}
	
	public void write(byte[] str) {
		try {
			if (fos == null) fos = new FileOutputStream(filePath, true);
			fos.write(str);
		}
		catch (IOException ioe) {
			System.out.println("[ERR] : OutputStream ���� Ȥ�� ���� ����.");
			ioe.printStackTrace();
		}
	}

	public void close() {
		try {
			fos.close();
		}
		catch (IOException ioe) {
			System.out.println("[ERR] : OutputStream �ݱ� ����.");
			ioe.printStackTrace();
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////
	////////////////////////////////////////////////////////////////////////////////////////////////
	
	public String getFilePath() {
		return filePath;
	}
}