package com.ksnet.util;

import java.io.FileOutputStream;
import java.io.IOException;

public class Logger {

	private StringBuffer logBuffer;

	// ������
	public Logger() {
		logBuffer = new StringBuffer();
	}
	
	// �α� ���
	public void log(String head, String body, String tail) {
		logBuffer.append(head).append(body).append(tail).append("\r\n");
	}

	// ���Ϸ� ���
	public void writeToFile(String logFilePath) {
		FileOutputStream fos = null;

		try {
			fos = new FileOutputStream(logFilePath, true);
			fos.write(String.valueOf(logBuffer).getBytes());
		}
		catch (IOException ioe1) {
			System.out.println("[����: OutputStream ���� Ȥ�� ���� ����.]");
			ioe1.printStackTrace();
		}
		finally {
			try {				
				if (fos != null) fos.close();
			}
			catch (IOException ioe2) {
				System.out.println("[����: OutputStream �ݱ� ����.]");
				ioe2.printStackTrace();
			}
		}
	}
}